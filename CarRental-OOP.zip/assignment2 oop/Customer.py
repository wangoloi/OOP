class Customer:
    def __init__(self, name, address): # This is a constructor method which initializes the name and address of the customer
        self.name = name # an instance 
        self.address = address

    def toString(self):
        return f"Customer Name: {self.name}, Address: {self.address}"


if __name__ == "__main__":
    customer = Customer("Mukama John", "Seeta ")#This is the customer object with name and his address
    print(customer.toString())#This displays the string representation of the customer
class Vehicle:
    def __init__(self, color):
        self.color = color

    def getColor(self):
        return self.color

    def toString(self):#This method returns a formatted string representation of the customer
        return f"{self.color} is the color of the vehicle."


if __name__ == "__main__":
    Vehicle1 = Vehicle("Silver-Grey")
    print(Vehicle1.getColor())

    print(Vehicle1.toString())
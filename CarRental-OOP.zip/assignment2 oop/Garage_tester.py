#This imports the Truck and Garage classes from their respective locations
from Truck import Truck
from Garage import Garage

class GarageTester:
    @staticmethod   # This creates a static method, which can be called without creating an instance of the class
    def getExample():
        truck = Truck(color="black", has_trailer=False)
        garage = Garage()
        garage.setVehicle(truck)
        return garage

if __name__ == "__main__":
    garage = GarageTester.getExample()
    print(garage.toString())
